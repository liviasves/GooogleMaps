package com.example.muitolegal;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        getCoordinatesFromAPI("UCSAL");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        enableMyLocation();

        getUserLocation();
    }

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation();
            } else {
                Toast.makeText(this, "Permissão de localização negada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getCoordinatesFromAPI(final String placeName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String apiKey = "AIzaSyDx2GWcQFuNizGaftA-xxU1IAyE_if8Rt8";
                    String urlString = "https://maps.googleapis.com/maps/api/geocode/json?address=" + placeName + "&key=" + apiKey;

                    URL url = new URL(urlString);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.connect();

                    InputStreamReader inputStreamReader = new InputStreamReader(urlConnection.getInputStream());
                    StringBuilder response = new StringBuilder();
                    int data = inputStreamReader.read();
                    while (data != -1) {
                        response.append((char) data);
                        data = inputStreamReader.read();
                    }

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    JSONArray results = jsonResponse.getJSONArray("results");

                    if (results.length() > 0) {
                        JSONObject location = results.getJSONObject(0)
                                .getJSONObject("geometry")
                                .getJSONObject("location");
                        double latitude = location.getDouble("lat");
                        double longitude = location.getDouble("lng");

                        Log.d("GeocodingAPI", "Latitude: " + latitude + " Longitude: " + longitude);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                LatLng placeCoordinates = new LatLng(latitude, longitude);
                                mMap.clear();
                                mMap.addMarker(new MarkerOptions().position(placeCoordinates).title(placeName));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(placeCoordinates, 15));
                            }
                        });
                    } else {
                        Log.e("GeocodingAPI", "Nenhum resultado encontrado para: " + placeName);
                    }

                    inputStreamReader.close();
                    urlConnection.disconnect();
                } catch (Exception e) {
                    Log.e("GeocodingAPI", "Erro ao fazer a requisição: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void getUserLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        if (location != null) {
                            LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());

                            CameraPosition cameraPosition = new CameraPosition.Builder()
                                    .target(userLocation)
                                    .zoom(15)
                                    .bearing(location.getBearing())
                                    .build();

                            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                            mMap.addMarker(new MarkerOptions().position(userLocation).title("Minha localização"));
                        } else {
                            Toast.makeText(MapsActivity.this, "Não foi possível obter a localização.", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }
}
